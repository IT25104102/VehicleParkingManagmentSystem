# Parking Slot Management System

This project is a Spring Boot web application for managing parking slots.

## Features
- Create parking slots
- Read/view all slots
- Update slot label and status
- Toggle slot status between available and occupied
- Delete slots
- File-based persistence using `parking-slots.txt`

## Running the application
1. Open the project in IntelliJ IDEA.
2. Build the project with Maven.
3. Run `ParkingSystemApplication`.
4. Open `http://localhost:8080/slots` in your browser.

## Notes
- The application uses JSP views under `src/main/webapp/WEB-INF/jsp`.
- Data is stored in `parking-slots.txt` at the project root.
