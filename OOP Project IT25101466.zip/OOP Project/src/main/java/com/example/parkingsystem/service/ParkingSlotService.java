package com.example.parkingsystem.service;

import com.example.parkingsystem.model.ParkingSlot;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class ParkingSlotService {
    private static final String STORAGE_FILE = "parking-slots.txt";
    private final List<ParkingSlot> slots = new ArrayList<>();

    @PostConstruct
    public void init() {
        loadSlots();
    }

    public List<ParkingSlot> getAllSlots() {
        return new ArrayList<>(slots);
    }

    public Optional<ParkingSlot> getSlotById(int id) {
        return slots.stream().filter(slot -> slot.getId() == id).findFirst();
    }

    public void addSlot(ParkingSlot slot) {
        slot.setId(nextId());
        slots.add(slot);
        saveSlots();
    }

    public void updateSlot(ParkingSlot updated) {
        getSlotById(updated.getId()).ifPresent(slot -> {
            slot.setLabel(updated.getLabel());
            slot.setOccupied(updated.isOccupied());
            saveSlots();
        });
    }

    public void toggleStatus(int id) {
        getSlotById(id).ifPresent(slot -> {
            slot.setOccupied(!slot.isOccupied());
            saveSlots();
        });
    }

    public void deleteSlot(int id) {
        slots.removeIf(slot -> slot.getId() == id);
        saveSlots();
    }

    private int nextId() {
        return slots.stream().map(ParkingSlot::getId).max(Comparator.naturalOrder()).orElse(0) + 1;
    }

    private void loadSlots() {
        try {
            Path path = Path.of(STORAGE_FILE);
            if (!Files.exists(path)) {
                Files.createFile(path);
            }
            try (BufferedReader reader = new BufferedReader(new FileReader(path.toFile()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        int id = Integer.parseInt(parts[0]);
                        String label = parts[1];
                        boolean occupied = Boolean.parseBoolean(parts[2]);
                        slots.add(new ParkingSlot(id, label, occupied));
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void saveSlots() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(new File(STORAGE_FILE), false))) {
            for (ParkingSlot slot : slots) {
                writer.write(slot.getId() + "," + slot.getLabel() + "," + slot.isOccupied());
                writer.newLine();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
