package com.example.parkingsystem.controller;

import com.example.parkingsystem.model.ParkingSlot;
import com.example.parkingsystem.service.ParkingSlotService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ParkingSlotController {
    private final ParkingSlotService parkingSlotService;

    public ParkingSlotController(ParkingSlotService parkingSlotService) {
        this.parkingSlotService = parkingSlotService;
    }

    @GetMapping({"/", "/slots"})
    public String listSlots(Model model) {
        model.addAttribute("slots", parkingSlotService.getAllSlots());
        return "list";
    }

    @GetMapping("/slots/new")
    public String showCreateForm(Model model) {
        model.addAttribute("slot", new ParkingSlot());
        return "create";
    }

    @PostMapping("/slots")
    public String addSlot(@ModelAttribute ParkingSlot slot) {
        parkingSlotService.addSlot(slot);
        return "redirect:/slots";
    }

    @GetMapping("/slots/edit/{id}")
    public String showEditForm(@PathVariable int id, Model model) {
        parkingSlotService.getSlotById(id).ifPresent(slot -> model.addAttribute("slot", slot));
        return "edit";
    }

    @PostMapping("/slots/update")
    public String updateSlot(@ModelAttribute ParkingSlot slot) {
        parkingSlotService.updateSlot(slot);
        return "redirect:/slots";
    }

    @GetMapping("/slots/toggle/{id}")
    public String toggleSlot(@PathVariable int id) {
        parkingSlotService.toggleStatus(id);
        return "redirect:/slots";
    }

    @GetMapping("/slots/delete/{id}")
    public String deleteSlot(@PathVariable int id) {
        parkingSlotService.deleteSlot(id);
        return "redirect:/slots";
    }
}
