package com.example.parkingsystem.model;

public class ParkingSlot {
    private int id;
    private String label;
    private boolean occupied;

    public ParkingSlot() {
    }

    public ParkingSlot(int id, String label, boolean occupied) {
        this.id = id;
        this.label = label;
        this.occupied = occupied;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    public String getStatus() {
        return occupied ? "Occupied" : "Available";
    }
}
