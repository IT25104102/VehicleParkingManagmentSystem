<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Create Parking Slot</title>
    <link rel="stylesheet" href="<c:url value='/css/styles.css'/>" />
</head>
<body>
<div class="container form-page">
    <header>
        <h1>Create New Parking Slot</h1>
    </header>
    <form action="${pageContext.request.contextPath}/slots" method="post">
        <div class="form-group">
            <label for="label">Slot Label</label>
            <input type="text" id="label" name="label" placeholder="e.g. A1" required />
        </div>
        <div class="form-group checkbox-group">
            <input type="checkbox" id="occupied" name="occupied" value="true" />
            <label for="occupied">Occupied</label>
        </div>
        <div class="form-actions">
            <button class="button primary" type="submit">Save Slot</button>
            <a class="button" href="${pageContext.request.contextPath}/slots">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
