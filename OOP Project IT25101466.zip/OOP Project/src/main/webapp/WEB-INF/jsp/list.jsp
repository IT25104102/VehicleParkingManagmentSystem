<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Parking Slot Management</title>
    <link rel="stylesheet" href="<c:url value='/css/styles.css'/>" />
    <script src="<c:url value='/js/script.js'/>"></script>
</head>
<body>
<div class="container">
    <header>
        <h1>Parking Slot Management</h1>
        <p>CRUD operations for parking slots with status toggle.</p>
    </header>

    <div class="toolbar">
        <a class="button primary" href="${pageContext.request.contextPath}/slots/new">Add New Slot</a>
    </div>

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Label</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="slot" items="${slots}">
            <tr class="${slot.occupied ? 'occupied' : 'available'}">
                <td>${slot.id}</td>
                <td>${slot.label}</td>
                <td>${slot.status}</td>
                <td>
                    <a class="button small" href="${pageContext.request.contextPath}/slots/edit/${slot.id}">Edit</a>
                    <a class="button small" href="${pageContext.request.contextPath}/slots/toggle/${slot.id}">Toggle</a>
                    <a class="button danger small" href="${pageContext.request.contextPath}/slots/delete/${slot.id}" onclick="return confirmDelete();">Delete</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>
