<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Parking Slot</title>
    <link rel="stylesheet" href="<c:url value='/css/styles.css'/>" />
</head>
<body>
<div class="container form-page">
    <header>
        <h1>Edit Parking Slot</h1>
    </header>
    <form action="${pageContext.request.contextPath}/slots/update" method="post">
        <input type="hidden" name="id" value="${slot.id}" />
        <div class="form-group">
            <label for="label">Slot Label</label>
            <input type="text" id="label" name="label" value="${slot.label}" required />
        </div>
        <div class="form-group checkbox-group">
            <input type="checkbox" id="occupied" name="occupied" value="true" ${slot.occupied ? 'checked' : ''} />
            <label for="occupied">Occupied</label>
        </div>
        <div class="form-actions">
            <button class="button primary" type="submit">Update Slot</button>
            <a class="button" href="${pageContext.request.contextPath}/slots">Back</a>
        </div>
    </form>
</div>
</body>
</html>
